<?php
//Reviewer submit review <review-name> for paper <paper-id> ;
$query=$argv[2];
$reviewer = $argv[1];
$arr= explode(" ",$query);
$dbconn2 = pg_connect("host=localhost port=5432 dbname=hotcrp1");
if(!$dbconn2) {
      echo "Error : Unable to open database\n";
   } 
else {
      echo "Opened database successfully\n";
   }


$review = "";
$paper_id = "";
$review = $arr[2];
$paper_id = $arr[5];

echo $review." ".$paper_id;


$q0="Set role C;";
$rslt0 = pg_exec($dbconn2, $q0);

$reader="";
$writer="";
$decision="";
$qry="select reader_set from main_table where user_id = '".$reviewer."' ;";
$result = pg_exec($dbconn2, $qry);
while($row = pg_fetch_row($result)) {
      $reader=$row[0];
}


$qry="select writer_set from main_table where user_id = '".$reviewer."' ;";
$result = pg_exec($dbconn2, $qry);
while($row = pg_fetch_row($result)) {
      $writer=$row[0];
}

$qry="select author from paper_details where paper_id = '".$paper_id."' ;";
$result = pg_exec($dbconn2, $qry);
while($row = pg_fetch_row($result)) {
      $writer=$writer.",".$row[0];
}


$qry="select decision_label from decision_table ;";
$result = pg_exec($dbconn2, $qry);
while($row = pg_fetch_row($result)) {
      $decision=$row[0];
}
//$decision="c-c-rr1,c,a1";
//$writer ="rr2,a1";

$decision_arr = explode("-",$decision);
if(sizeof($decision_arr[2])==1)
	$decision_arr[2]=$decision_arr[2].",c";
$decision_writer = explode(",",$decision_arr[2]);

$writer_arr = explode(",",$writer);

$review_wrt = sizeof($writer_arr);
$decision_wrt = sizeof($decision_writer);

$subject_list=array("red");
for($i=0;$i<$review_wrt;$i++)
{
	array_push($subject_list,$writer_arr[$i]) ;
}
//echo "writer-set ".$writer_set." writer ".$writer;
$flag=0;
for($j=0;$j<$decision_wrt;$j++)
{
		for($k=0;$k<sizeof($subject_list);$k++)
		{
			if($decision_writer[$j] == $subject_list[$k])
			{
				$flag=1;
				break;	
	 		}
		}
		if($flag == 0)
		{
			array_push($subject_list,$decision_writer[$j]);
		}
		$flag=0;
		
}

$writer_set="";
$writer_set=$subject_list[1];
for($i=2;$i<sizeof($subject_list);$i++)
{
	$writer_set = $writer_set.",".$subject_list[$i];
}



$q1="update review_decision set decision = 'c-c-".$writer_set."'  where paper_id = '".$paper_id."';";
$rslt1 = pg_exec($dbconn2, $q1);

$q1="update review_decision set l_".$reviewer." = 'c-c-c,".$writer."' where paper_id = '".$paper_id."';";
$rslt1 = pg_exec($dbconn2, $q1);

$q1="update review_decision set ".$reviewer." = '".$review."' where paper_id = '".$paper_id."';";
$rslt1 = pg_exec($dbconn2, $q1);

$q1="update decision_table set decision_label = 'c-c-".$writer_set."' ;";
$rslt1 = pg_exec($dbconn2, $q1);


echo "writer-set ".$writer_set ;

?> 

