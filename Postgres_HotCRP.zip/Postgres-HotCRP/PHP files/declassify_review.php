<?php
//declassify reviews to subject-name for paper paper-id ;
$query=$argv[1];
$arr= explode(" ",$query);
$dbconn2 = pg_connect("host=localhost port=5432 dbname=hotcrp1");
if(!$dbconn2) {
      echo "Error : Unable to open database\n";
   } else {
      echo "Opened database successfully\n";
   }

$paper_id = $arr[6];
$subject = $arr[3];

$q0="Set role C;";
$rslt0 = pg_exec($dbconn2, $q0);

$qry="select decision_label from decision_table ;";
$result = pg_exec($dbconn2, $qry);
while($row = pg_fetch_row($result)) {
      $decision=$row[0];
}
//$decision="c-c-c,A1,RR1,D";


$decision_arr = explode("-",$decision);
$decision_writer = explode(",",$decision_arr[2]);

$flag=0;
for($j=0;$j<sizeof($decision_writer);$j++)
{
		if($decision_writer[$j]==$subject)
		{
			$flag=1;
			break;
		}
}

if($flag==1)
{
	$decision_reader=$decision_arr[1].",".$subject;
	echo $decision_reader." ".$subject ;
	$qry="update review_decision set decision = 'c-".$decision_reader."-".$decision_arr[2]."' where paper_id = '".$paper_id."' ;";
	$result = pg_exec($dbconn2, $qry);
	$qry="update review_decision set access = access || ',".$subject."' where paper_id = '".$paper_id."' ;";
	$result = pg_exec($dbconn2, $qry);
	$qry="update decision_table set decision_label = 'c-".$decision_reader."-".$decision_arr[2]."' ;";
	$result = pg_exec($dbconn2, $qry);
	
}
		
?> 

